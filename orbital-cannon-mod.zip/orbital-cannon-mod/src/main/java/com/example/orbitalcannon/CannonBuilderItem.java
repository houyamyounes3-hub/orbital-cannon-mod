package com.example.orbitalcannon;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.structure.StructurePlacementData;
import net.minecraft.structure.StructureTemplate;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.Optional;

public class CannonBuilderItem extends Item {
    public CannonBuilderItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext ctx) {
        World world = ctx.getWorld();
        if (world.isClient) return ActionResult.SUCCESS;

        ServerWorld sw = (ServerWorld) world;
        BlockPos origin = ctx.getBlockPos().up();

        // Drop a structure file at data/orbitalcannon/structure/orbital_cannon.nbt
        // and that gets built instead of the built-in version below.
        Identifier id = Identifier.of(OrbitalCannonMod.MOD_ID, "orbital_cannon");
        Optional<StructureTemplate> template = sw.getStructureTemplateManager().getTemplate(id);

        if (template.isPresent()) {
            StructureTemplate t = template.get();
            BlockPos at = origin.add(-t.getSize().getX() / 2, 0, -t.getSize().getZ() / 2);
            t.place(sw, at, at, new StructurePlacementData(), sw.getRandom(), Block.NOTIFY_LISTENERS);
        } else {
            buildDefault(sw, origin);
        }

        if (ctx.getPlayer() != null) {
            ctx.getPlayer().sendMessage(Text.literal("Orbital cannon built!"), true);
        }
        return ActionResult.SUCCESS;
    }

    private void fill(ServerWorld w, BlockPos o, int x1, int y1, int z1, int x2, int y2, int z2, Block b) {
        for (int x = x1; x <= x2; x++)
            for (int y = y1; y <= y2; y++)
                for (int z = z1; z <= z2; z++)
                    w.setBlockState(o.add(x, y, z), b.getDefaultState(), Block.NOTIFY_LISTENERS);
    }

    /** Simplified cannon: base, tower, TNT ring and firing platform. */
    private void buildDefault(ServerWorld w, BlockPos o) {
        fill(w, o, -8, 0, -8, 8, 0, 8, Blocks.STONE_BRICKS);   // base
        fill(w, o, -1, 1, -1, 1, 24, 1, Blocks.IRON_BLOCK);     // tower
        fill(w, o, 0, 1, 0, 0, 24, 0, Blocks.GLASS);            // glass core
        fill(w, o, -6, 25, -6, 6, 25, 6, Blocks.OBSIDIAN);      // firing platform
        fill(w, o, -6, 26, -6, 6, 27, 6, Blocks.TNT);           // TNT block
        fill(w, o, -4, 26, -4, 4, 27, 4, Blocks.AIR);           // hollow into a ring
        fill(w, o, -1, 26, -1, 1, 30, 1, Blocks.IRON_BLOCK);    // barrel
        fill(w, o, 0, 26, 0, 0, 30, 0, Blocks.AIR);            // barrel bore
        w.setBlockState(o.add(0, 31, 0), Blocks.REDSTONE_BLOCK.getDefaultState(), Block.NOTIFY_LISTENERS);
    }
}
