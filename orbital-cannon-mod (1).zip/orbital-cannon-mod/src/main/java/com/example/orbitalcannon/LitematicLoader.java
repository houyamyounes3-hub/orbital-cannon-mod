package com.example.orbitalcannon;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtSizeTracker;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Property;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** Reads a Litematica .litematic file and pastes its blocks into the world. */
public final class LitematicLoader {
    private LitematicLoader() {}

    private record Region(int minX, int minY, int minZ, int sx, int sy, int sz,
                          BlockState[] palette, long[] data, int bits) {}

    public static int paste(ServerWorld world, InputStream in, BlockPos origin) throws IOException {
        NbtCompound root = NbtIo.readCompressed(in, NbtSizeTracker.ofUnlimitedBytes());
        NbtCompound regionsTag = root.getCompound("Regions");

        List<Region> regions = new ArrayList<>();
        int bx = Integer.MAX_VALUE, by = Integer.MAX_VALUE, bz = Integer.MAX_VALUE;
        int ex = Integer.MIN_VALUE, ez = Integer.MIN_VALUE;

        for (String name : regionsTag.getKeys()) {
            NbtCompound r = regionsTag.getCompound(name);
            NbtCompound pos = r.getCompound("Position");
            NbtCompound size = r.getCompound("Size");

            int rx = size.getInt("x"), ry = size.getInt("y"), rz = size.getInt("z");
            int sx = Math.abs(rx), sy = Math.abs(ry), sz = Math.abs(rz);
            int minX = pos.getInt("x") + (rx < 0 ? rx + 1 : 0);
            int minY = pos.getInt("y") + (ry < 0 ? ry + 1 : 0);
            int minZ = pos.getInt("z") + (rz < 0 ? rz + 1 : 0);

            NbtList pal = r.getList("BlockStatePalette", NbtElement.COMPOUND_TYPE);
            BlockState[] states = new BlockState[pal.size()];
            for (int i = 0; i < states.length; i++) {
                states[i] = parseState(pal.getCompound(i));
            }
            int bits = Math.max(2, 32 - Integer.numberOfLeadingZeros(pal.size() - 1));
            regions.add(new Region(minX, minY, minZ, sx, sy, sz, states, r.getLongArray("BlockStates"), bits));

            bx = Math.min(bx, minX);
            by = Math.min(by, minY);
            bz = Math.min(bz, minZ);
            ex = Math.max(ex, minX + sx);
            ez = Math.max(ez, minZ + sz);
        }
        if (regions.isEmpty()) return 0;

        // Put the schematic's bottom centre on the clicked spot.
        int offX = origin.getX() - (bx + (ex - bx) / 2);
        int offY = origin.getY() - by;
        int offZ = origin.getZ() - (bz + (ez - bz) / 2);

        int placed = 0;
        BlockPos.Mutable p = new BlockPos.Mutable();
        for (Region reg : regions) {
            for (int y = 0; y < reg.sy(); y++) {
                for (int z = 0; z < reg.sz(); z++) {
                    for (int x = 0; x < reg.sx(); x++) {
                        long index = ((long) y * reg.sz() + z) * reg.sx() + x;
                        int id = readBits(reg.data(), reg.bits(), index);
                        if (id < 0 || id >= reg.palette().length) continue;
                        BlockState state = reg.palette()[id];
                        if (state.isAir()) continue;
                        p.set(reg.minX() + x + offX, reg.minY() + y + offY, reg.minZ() + z + offZ);
                        if (world.isOutOfHeightLimit(p)) continue;
                        world.setBlockState(p, state, Block.NOTIFY_LISTENERS | Block.FORCE_STATE);
                        placed++;
                    }
                }
            }
        }
        return placed;
    }

    private static int readBits(long[] arr, int bits, long index) {
        long start = index * bits;
        int i = (int) (start >>> 6);
        int off = (int) (start & 63);
        if (i >= arr.length) return 0;
        long v = arr[i] >>> off;
        if (off + bits > 64 && i + 1 < arr.length) {
            v |= arr[i + 1] << (64 - off);
        }
        return (int) (v & ((1L << bits) - 1));
    }

    private static BlockState parseState(NbtCompound tag) {
        Identifier id = Identifier.tryParse(tag.getString("Name"));
        if (id == null || !Registries.BLOCK.containsId(id)) return Blocks.AIR.getDefaultState();
        Block block = Registries.BLOCK.get(id);
        BlockState state = block.getDefaultState();
        if (tag.contains("Properties")) {
            NbtCompound props = tag.getCompound("Properties");
            for (Property<?> prop : block.getStateManager().getProperties()) {
                if (props.contains(prop.getName())) {
                    state = withProp(state, prop, props.getString(prop.getName()));
                }
            }
        }
        return state;
    }

    private static <T extends Comparable<T>> BlockState withProp(BlockState s, Property<T> prop, String value) {
        Optional<T> v = prop.parse(value);
        return v.isPresent() ? s.with(prop, v.get()) : s;
    }
}
