package com.example.orbitalcannon;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.structure.StructurePlacementData;
import net.minecraft.structure.StructureTemplate;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;
import java.util.stream.Stream;

public class CannonBuilderItem extends Item {
    public CannonBuilderItem(Settings settings) {
        super(settings);
    }

    /** Folder where you put the cannon schematic: .minecraft/config/orbitalcannon/ */
    public static Path schematicDir() {
        return FabricLoader.getInstance().getConfigDir().resolve("orbitalcannon");
    }

    private static Path findLitematic() {
        Path dir = schematicDir();
        if (!Files.isDirectory(dir)) return null;
        try (Stream<Path> s = Files.list(dir)) {
            return s.filter(p -> p.getFileName().toString().toLowerCase().endsWith(".litematic"))
                    .findFirst().orElse(null);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext ctx) {
        World world = ctx.getWorld();
        if (world.isClient) return ActionResult.SUCCESS;

        ServerWorld sw = (ServerWorld) world;
        BlockPos origin = ctx.getBlockPos().up();

        // 1) a .litematic in config/orbitalcannon/ overrides the built-in cannon
        // 2) otherwise the cannon packed inside the mod is used
        try {
            Path lit = findLitematic();
            InputStream in = lit != null ? Files.newInputStream(lit)
                    : CannonBuilderItem.class.getResourceAsStream("/orbital_cannon.litematic");
            if (in != null) {
                try (InputStream stream = in) {
                    int n = LitematicLoader.paste(sw, stream, origin);
                    tell(ctx, "Orbital Strike Cannon built (" + n + " blocks)");
                }
                return ActionResult.SUCCESS;
            }
        } catch (Throwable t) {
            tell(ctx, "Failed to build cannon: " + t);
            return ActionResult.SUCCESS;
        }

        Identifier id = Identifier.of(OrbitalCannonMod.MOD_ID, "orbital_cannon");
        Optional<StructureTemplate> template = sw.getStructureTemplateManager().getTemplate(id);
        if (template.isPresent()) {
            StructureTemplate t = template.get();
            BlockPos at = origin.add(-t.getSize().getX() / 2, 0, -t.getSize().getZ() / 2);
            t.place(sw, at, at, new StructurePlacementData(), sw.getRandom(), Block.NOTIFY_LISTENERS);
            tell(ctx, "Orbital cannon built!");
        } else {
            buildDefault(sw, origin);
            tell(ctx, "No .litematic found in config/orbitalcannon/ - built the simple tower instead.");
        }
        return ActionResult.SUCCESS;
    }

    private void tell(ItemUsageContext ctx, String msg) {
        if (ctx.getPlayer() != null) ctx.getPlayer().sendMessage(Text.literal(msg), false);
    }

    private void fill(ServerWorld w, BlockPos o, int x1, int y1, int z1, int x2, int y2, int z2, Block b) {
        for (int x = x1; x <= x2; x++)
            for (int y = y1; y <= y2; y++)
                for (int z = z1; z <= z2; z++)
                    w.setBlockState(o.add(x, y, z), b.getDefaultState(), Block.NOTIFY_LISTENERS);
    }

    private void buildDefault(ServerWorld w, BlockPos o) {
        fill(w, o, -8, 0, -8, 8, 0, 8, Blocks.STONE_BRICKS);
        fill(w, o, -1, 1, -1, 1, 24, 1, Blocks.IRON_BLOCK);
        fill(w, o, 0, 1, 0, 0, 24, 0, Blocks.GLASS);
        fill(w, o, -6, 25, -6, 6, 25, 6, Blocks.OBSIDIAN);
        fill(w, o, -6, 26, -6, 6, 27, 6, Blocks.TNT);
        fill(w, o, -4, 26, -4, 4, 27, 4, Blocks.AIR);
        fill(w, o, -1, 26, -1, 1, 30, 1, Blocks.IRON_BLOCK);
        fill(w, o, 0, 26, 0, 0, 30, 0, Blocks.AIR);
        w.setBlockState(o.add(0, 31, 0), Blocks.REDSTONE_BLOCK.getDefaultState(), Block.NOTIFY_LISTENERS);
    }
}
