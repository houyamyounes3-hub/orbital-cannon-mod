package com.example.orbitalcannon;

import net.minecraft.entity.TntEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Right-click: rains a grid of TNT from the sky onto the spot you are aiming at. */
public class StrikeRodItem extends Item {
    private static final int HALF = 3;      // 7 x 7 grid
    private static final int LAYERS = 2;    // two layers of TNT -> 98 TNT
    private static final int HEIGHT = 60;   // spawn height above the target
    private static final int FUSE = 50;     // ticks before each TNT explodes

    public StrikeRodItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult use(World world, PlayerEntity user, Hand hand) {
        if (world.isClient) return ActionResult.SUCCESS;

        HitResult hit = user.raycast(300.0, 0.0f, false);
        if (hit.getType() == HitResult.Type.MISS) {
            user.sendMessage(Text.literal("Aim at the ground or a block first."), true);
            return ActionResult.FAIL;
        }

        Vec3d target = hit.getPos();
        double y = Math.min(target.y + HEIGHT, world.getTopY() - 3);

        for (int layer = 0; layer < LAYERS; layer++) {
            for (int dx = -HALF; dx <= HALF; dx++) {
                for (int dz = -HALF; dz <= HALF; dz++) {
                    TntEntity tnt = new TntEntity(world, target.x + dx, y + layer * 2, target.z + dz, user);
                    tnt.setFuse(FUSE);
                    tnt.setVelocity(0.0, -1.0, 0.0);
                    world.spawnEntity(tnt);
                }
            }
        }
        user.sendMessage(Text.literal("Orbital strike incoming!"), true);
        return ActionResult.SUCCESS;
    }
}
