package com.example.orbitalcannon;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;

public class OrbitalCannonMod implements ModInitializer {
    public static final String MOD_ID = "orbitalcannon";
    public static Item CANNON_BUILDER;
    public static Item STRIKE_ROD;

    @Override
    public void onInitialize() {
        try { java.nio.file.Files.createDirectories(CannonBuilderItem.schematicDir()); } catch (Exception ignored) {}
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(MOD_ID, "cannon_builder"));
        CANNON_BUILDER = Registry.register(Registries.ITEM, key,
                new CannonBuilderItem(new Item.Settings().registryKey(key).maxCount(1).rarity(Rarity.EPIC)));
        RegistryKey<Item> rodKey = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(MOD_ID, "strike_rod"));
        STRIKE_ROD = Registry.register(Registries.ITEM, rodKey,
                new StrikeRodItem(new Item.Settings().registryKey(rodKey).maxCount(1).rarity(Rarity.EPIC)));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> { e.add(CANNON_BUILDER); e.add(STRIKE_ROD); });
    }
}
